<?php $title = "Homepage"; ?>
<?php include "header.php"; ?>

<div class="container">
<p style="margin:400px 0">Body</p>
</div>

<?php include "footer.php"; ?>



