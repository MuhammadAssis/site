<script src="assets/js/jquery-3.5.1.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

<footer class="pt-4 pt-md-5 border-top">
<div class="container">
<div class="row">
    <!--<div class="col-12 col-md">
        <img class="mb-2" src="https://getbootstrap.com/docs/4.0/assets/brand/bootstrap-solid.svg" alt="" width="24" height="24">
        <small class="d-block mb-3 ">� 2017-2018</small>
    </div>-->
    <div class="col-6 col-md">
        <h5>Features</h5>
        <ul class="list-unstyled text-small">
            <li><a  href="#">Cool stuff</a></li>
            <li><a  href="#">Random feature</a></li>
            <li><a  href="#">Team feature</a></li>
            <li><a  href="#">Stuff for developers</a></li>
            <li><a  href="#">Another one</a></li>
            <li><a  href="#">Last time</a></li>
        </ul>
    </div>
    <div class="col-6 col-md">
        <h5>Resources</h5>
        <ul class="list-unstyled text-small">
            <li><a  href="#">Resource</a></li>
            <li><a  href="#">Resource name</a></li>
            <li><a  href="#">Another resource</a></li>
            <li><a  href="#">Final resource</a></li>
        </ul>
    </div>
    <div class="col-6 col-md">
        <h5>Support</h5>
        <ul class="list-unstyled text-small">
            <li><a  href="#">Team</a></li>
            <li><a  href="#">Locations</a></li>
            <li><a  href="#">Privacy</a></li>
            <li><a  href="#">Terms</a></li>
        </ul>
    </div>
    <div class="col-6 col-md">
        <h5>About</h5>
        <ul class="list-unstyled text-small">
            <li><a  href="#">Team</a></li>
            <li><a  href="#">Locations</a></li>
            <li><a  href="#">Privacy</a></li>
            <li><a  href="#">Terms</a></li>
        </ul>
    </div>
    <div class="col-6 col-md">
        <h5>Contact</h5>
        <ul class="list-unstyled text-small">
            <li><a  href="#">contact@email.com</a></li>
        </ul>
    </div>
</div>

<div class="row">
    <hr>
</div>

<div class="row">
<div class="col-md-6">
<img width="93" src="assets/img/footer-logo.png" alt="" />
<p>Privacy Policy  Cookie Policy Terms & Conditions</p>
<p>2035 Sunset Lake Road, Suite B-2, Newark, Delaware 1970</p>
<p>Adriel  2020. All Rights Reserved.</p>
</div>
<div class="col-md-6">


<select name="" id="" class="form-control col-4 float-right">
<option>English</option>
<option>Arabic</option>
</select>

</div>
</div>


</div>
</footer>